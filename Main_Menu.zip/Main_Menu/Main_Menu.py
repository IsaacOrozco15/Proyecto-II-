import pygame
import sys
import math

# Inicializar pygame
pygame.init()

pygame.mixer.init()

ANCHO, ALTO = 800, 600
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Escapa del Laberinto")
fondo_imagen = pygame.image.load("Fondo_Escapa.jpg")
fondo_imagen = pygame.transform.scale(fondo_imagen, (ANCHO, ALTO))  # Ajusta al tamaño de pantalla


# Música de fondo
pygame.mixer.music.load("OSTMM.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1)

# Colores
NEGRO = (0, 0, 0)
BLANCO = (255, 255, 255)
VERDE = (0, 200, 0)
VERDE_CLARO = (0, 255, 0)
AZUL = (0, 150, 255)
NARANJA = (255, 140, 0)
ROJO = (200, 0, 0)
ROJO_CLARO = (255, 0, 0)
GRIS_OSCURO = (30, 30, 30)

# Fuente
fuente = pygame.font.SysFont("arial", 50)
fuente_pequeña = pygame.font.SysFont("arial", 30)

# FPS
reloj = pygame.time.Clock()

# Fondos e imágenes
fondo = pygame.image.load("Fondo_Escapa.jpg")
fondo = pygame.transform.scale(fondo, (ANCHO, ALTO))

logo = pygame.image.load("Logo_Escapa.png")
logo = pygame.transform.scale(logo, (400, 200))

def dibujar_texto(texto, fuente, color, superficie, x, y):
    texto_obj = fuente.render(texto, True, color)
    texto_rect = texto_obj.get_rect(center=(x, y))
    superficie.blit(texto_obj, texto_rect)

def dibujar_boton_tk(pantalla, rect, texto, fuente, presionado=False, texto_color=NEGRO):
    # Colores Tkinter
    bg_normal = (240, 240, 240)
    bg_pressed = (220, 220, 220)

    borde_claro = (255, 255, 255)
    borde_oscuro = (160, 160, 160)

    # Si está presionado, invertir bordes
    if presionado:
        bg = bg_pressed
        b1 = borde_oscuro
        b2 = borde_claro
        offset_texto = 2
    else:
        bg = bg_normal
        b1 = borde_claro
        b2 = borde_oscuro
        offset_texto = 0

    # Fondo
    pygame.draw.rect(pantalla, bg, rect)

    # Bordes estilo Tkinter
    pygame.draw.line(pantalla, b1, rect.topleft, (rect.right, rect.top), 2)
    pygame.draw.line(pantalla, b1, rect.topleft, (rect.left, rect.bottom), 2)

    pygame.draw.line(pantalla, b2, (rect.left, rect.bottom), rect.bottomright, 2)
    pygame.draw.line(pantalla, b2, (rect.right, rect.top), rect.bottomright, 2)

    # Texto (baja si está presionado)
    texto_obj = fuente.render(texto, True, texto_color)
    texto_rect = texto_obj.get_rect(center=(rect.centerx, rect.centery + offset_texto))
    pantalla.blit(texto_obj, texto_rect)


    # Fondo
    pygame.draw.rect(pantalla, bg, rect)

    # Borde relieve estilo Tkinter (elevado)
    pygame.draw.line(pantalla, borde_claro, rect.topleft, (rect.right, rect.top), 2)
    pygame.draw.line(pantalla, borde_claro, rect.topleft, (rect.left, rect.bottom), 2)

    pygame.draw.line(pantalla, borde_oscuro, (rect.left, rect.bottom), rect.bottomright, 2)
    pygame.draw.line(pantalla, borde_oscuro, (rect.right, rect.top), rect.bottomright, 2)

    # Texto
    dibujar_texto(texto, fuente, texto_color, pantalla, rect.centerx, rect.centery)


def transicion_a_negro(pantalla):
    superficie_negra = pygame.Surface((ANCHO, ALTO))
    superficie_negra.fill((0, 0, 0))

    for alpha in range(0, 256, 5):  # Va de 0 a 255 en pasos de 5
        superficie_negra.set_alpha(alpha)  # Ajusta opacidad
        pantalla.blit(superficie_negra, (0, 0))
        pygame.display.flip()
        pygame.time.delay(20)  # Controla la velocidad del fundido

def transicion_desde_negro(pantalla, fondo):
    superficie_negra = pygame.Surface((ANCHO, ALTO))
    superficie_negra.fill((0, 0, 0))

    for alpha in range(255, -1, -5):  # De opaco (255) a transparente (0)
        pantalla.blit(fondo, (0, 0))  # Dibuja primero el fondo
        superficie_negra.set_alpha(alpha)
        pantalla.blit(superficie_negra, (0, 0))
        pygame.display.flip()
        pygame.time.delay(20)

def mostrar_cinematica():
    en_cinematica = True
    reloj = pygame.time.Clock()

    historia = [
        "En un futuro no muy lejano...",
        "Una Purga a nivel mundial comenzaba",
        "El mundo jamás volvió a ser el mismo.",
        "Civilizaciones enteras desaparecieron sin dejar rastro",
        "El propio anarquismo llevo al mundo a ser dividido en dos",
        "Cazadores, y Sobrevivientes"
    ]

    fuente = pygame.font.SysFont("Arial", 28)

    def dividir_en_lineas(texto, fuente, max_ancho):
        palabras = texto.split(" ")
        lineas = []
        linea_actual = ""
        for palabra in palabras:
            test_linea = linea_actual + palabra + " "
            if fuente.size(test_linea)[0] <= max_ancho:
                linea_actual = test_linea
            else:
                lineas.append(linea_actual.strip())
                linea_actual = palabra + " "
        lineas.append(linea_actual.strip())
        return lineas

    indice = 0
    esperando_entrada = False
    texto_actual = ""
    letras_mostradas = 0
    tiempo_anterior = pygame.time.get_ticks()
    velocidad = 40  # ms entre letras

    while en_cinematica:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if evento.type == pygame.KEYDOWN and esperando_entrada:
                indice += 1
                if indice >= len(historia):
                    en_cinematica = False
                else:
                    texto_actual = ""
                    letras_mostradas = 0
                    tiempo_anterior = pygame.time.get_ticks()
                    esperando_entrada = False

        pantalla.fill(NEGRO)

        if indice < len(historia):
            texto = historia[indice]

            if not esperando_entrada:
                tiempo_actual = pygame.time.get_ticks()
                if letras_mostradas < len(texto):
                    if tiempo_actual - tiempo_anterior >= velocidad:
                        letras_mostradas += 1
                        texto_actual = texto[:letras_mostradas]
                        tiempo_anterior = tiempo_actual
                else:
                    esperando_entrada = True

            lineas = dividir_en_lineas(texto_actual, fuente, ANCHO - 100)
            altura_total = len(lineas) * fuente.get_height()
            y_inicial = (ALTO - altura_total) // 2

            for i, linea in enumerate(lineas):
                superficie_texto = fuente.render(linea, True, BLANCO)
                rect = superficie_texto.get_rect(center=(ANCHO // 2, y_inicial + i * fuente.get_height()))
                pantalla.blit(superficie_texto, rect)

        pygame.display.flip()
        reloj.tick(60)



def pantalla_dificultad():
    while True:
        pantalla.blit(fondo,(0,0))
        mx, my = pygame.mouse.get_pos()

        # Botones de modos de juego
        boton_hunter_mode = pygame.Rect(300, 200, 200, 50)
        boton_escape_mode = pygame.Rect(300, 270, 200, 50)
        boton_volver = pygame.Rect(300, 420, 200, 50)

        # Detectar si están presionados
        pres_hunter = pygame.mouse.get_pressed()[0] and boton_hunter_mode.collidepoint((mx, my))
        pres_escape = pygame.mouse.get_pressed()[0] and boton_escape_mode.collidepoint((mx, my))
        pres_volver = pygame.mouse.get_pressed()[0] and boton_volver.collidepoint((mx, my))

        # Dibujar botones estilo Tkinter con texto negro
        dibujar_boton_tk(pantalla, boton_hunter_mode, "CAZADOR", fuente_pequeña,
                         presionado=pres_hunter, texto_color=NEGRO)

        dibujar_boton_tk(pantalla, boton_escape_mode, "SOBREVIVIENTE", fuente_pequeña,
                         presionado=pres_escape, texto_color=NEGRO)

        dibujar_boton_tk(pantalla, boton_volver, "VOLVER", fuente_pequeña,
                         presionado=pres_volver, texto_color=NEGRO)

        # Título
        dibujar_texto("SELECCIONA DIFICULTAD", fuente_pequeña, BLANCO, pantalla,
                      ANCHO//2, 100)

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.MOUSEBUTTONDOWN:
                if boton_hunter_mode.collidepoint((mx, my)):
                    print("Modo cazador seleccionado")

                if boton_escape_mode.collidepoint((mx, my)):
                    print("Modo sobreviviente seleccionado")

                if boton_volver.collidepoint((mx, my)):
                    transicion_a_negro(pantalla)
                    transicion_desde_negro(pantalla, fondo_imagen)
                    return  # Vuelve al menú principal

        pygame.display.flip()
        reloj.tick(60)



def menu_principal():
    while True:
        pantalla.blit(fondo, (0, 0))

        # Animación suave del logo

        t = pygame.time.get_ticks() / 1000
        offset = math.sin(t * 2) * 5
        pantalla.blit(logo, (ANCHO // 2 - 200, 40 + offset))

        mx, my = pygame.mouse.get_pos()

        boton_jugar = pygame.Rect(300, 270, 200, 50)
        boton_opciones = pygame.Rect(300, 340, 200, 50)
        boton_salir = pygame.Rect(300, 410, 200, 50)
        
        for boton, texto in zip([boton_jugar, boton_opciones, boton_salir],
                                ["JUGAR", "OPCIONES", "SALIR"]):
            esta_presionado = pygame.mouse.get_pressed()[0] and boton.collidepoint((mx, my))
            dibujar_boton_tk(pantalla, boton, texto, fuente_pequeña, presionado=esta_presionado)




        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.MOUSEBUTTONDOWN:
                if boton_jugar.collidepoint((mx, my)):
                    transicion_a_negro(pantalla)
                    transicion_desde_negro(pantalla, fondo_imagen)
                    pantalla_dificultad()
                    

                if boton_opciones.collidepoint((mx, my)):
                    print("Abriendo opciones...")
                if boton_salir.collidepoint((mx, my)):
                    pygame.quit()
                    sys.exit()

        pygame.display.flip()
        reloj.tick(60)


# INICIO DEL JUEGO

if __name__ == "__main__":
    transicion_a_negro(pantalla)           # Pantalla se oscurece
    mostrar_cinematica()                   # Muestra la historia (epílogo)
    transicion_desde_negro(pantalla, fondo_imagen)  # Transición suave al fondo
    menu_principal()                       # Lanza el menú